package com.xiaoshu.memorandum.activity;
/**
 * Created by WangYiWen on 2018/4/8.
 */
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import com.xiaoshu.memorandum.R;

public class AboutActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);
    }
}
